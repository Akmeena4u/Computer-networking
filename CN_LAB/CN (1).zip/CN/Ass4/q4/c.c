#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
    system("gcc p1.c -o p1");
    system("gcc p2.c -o p2");
}