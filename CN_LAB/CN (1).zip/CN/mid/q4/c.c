#include<stdlib.h>
int main()
{
    system("gcc editor.c -o editor");
    system("gcc news_reader2.c -o news2");
    system("gcc news_reader1.c -o news1");
    system("gcc reporters.c -o reporters");
    system("gcc screen.c -o screen");
}