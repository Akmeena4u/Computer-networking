
#!/bin/bash
for i in {1..20}
do
   ./client $i.txt
done