#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *args[])
{
    printf("%d\n",argc);
    if (argc < 4)
    {
        char buff[100];
        read(0,buff,100);
        printf("P4 : read %s\n", buff);
    }
    int c = fork();
    int fd[2];
    pipe(fd);
    if (c == 0)
    {
        close(fd[1]);
        dup2(fd[0], 0);
        char *argv[argc - 1];
        for (int i = 2; i < argc; i++)
            argv[i - 2] = args[i];
        argv[argc - 2] = NULL;
        char path[20];
        sprintf(path, "./%s", argv);
        execv(path, argv);
    }
    else
    {
        close(fd[0]);
        if (argc > 1)
        {
            char buff[100];
            sprintf(buff,"Message from P4");
            write(fd[1],buff,100);
        }
    }
}